/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ffos.controller;

import ffos.model.Plesac;
import ffos.model.Pozornica;
import java.util.List;

/**
 *
 * @author Korisnik
 */
public class ObradaPlesac extends Obrada <Plesac> {

    public void SetData(String ime, String prezime){
    if(getEntitet()==null){
    Plesac m = new Plesac();
        try {
            m.setIme(ime);
            m.setPrezime(prezime);
        } catch (Exception ex) {
        } setEntitet(m);
    } else {
        try {
            getEntitet().setIme(ime);
            getEntitet().setPrezime(prezime);
        } catch (Exception e) {
        }
    }
        
    }
    
    public List <Plesac> read(){
    return session.createQuery("from Plesac").list();
    }
    
    @Override
    public void kontrolaCreate() throws Exception {
    }

    @Override
    public void kontrolaUpdate() throws Exception {
    }

    @Override
    public void kontrolaDelete() throws Exception {
    }
    
}
