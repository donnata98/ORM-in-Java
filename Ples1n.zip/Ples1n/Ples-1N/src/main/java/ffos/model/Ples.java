/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ffos.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Korisnik
 */

@Entity
public class Ples extends Entitet {
    private Integer broj;
    
    @Temporal(TemporalType.DATE)
    private Date datum;
    @ManyToOne
    private Plesac plesac;
    @ManyToOne
    private Pozornica pozornica;

    public Integer getBroj() {
        return broj;
    }

    public void setBroj(Integer broj) {
        this.broj = broj;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public Plesac getPlesac() {
        return plesac;
    }

    public void setPlesac(Plesac plesac) {
        this.plesac = plesac;
    }

    public Pozornica getPozornica() {
        return pozornica;
    }

    public void setPozornica(Pozornica pozornica) {
        this.pozornica = pozornica;
    }
    
    
     @Override
    public String toString() {
        return datum + "," + broj;
    }
    
}
